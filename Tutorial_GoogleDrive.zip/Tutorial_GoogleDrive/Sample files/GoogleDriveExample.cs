﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoogleDriveUploader.GoogleDrive;
using System.IO;

namespace GoogleDriveUploader.View
{
    public partial class GoogleDriveExample : Form
    {
        private string _uploadFileName;
        private string _downloadPath;
        GoogleDriveService _service;

        public GoogleDriveExample()
        {
            
        }

        private void ClickBrowseUploadFileButton(object sender, EventArgs e)
        {
            
        }

        private void ClickUploadButton(object sender, EventArgs e)
        {
            
        }

        private void ClickListFileOnRootButton(object sender, EventArgs e)
        {
            
        }

        private void ClickDownloadBrowseButton(object sender, EventArgs e)
        {
            
        }

        private void ClickDownloadButton(object sender, EventArgs e)
        {
            
        }

        private void ClickUpdateButton(object sender, EventArgs e)
        {
            
        }

        private void ClickDeleteButton(object sender, EventArgs e)
        {
            
        }
    }
}
